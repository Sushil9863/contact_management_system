<style>
    nav{
        color: white;
        background-color: #0c5460;
    }

    .color-white{
        color: white !important;
    }

    .color-green{
        color: #76cf41;
    }

    .hover-text:hover{
        color: white;
        text-decoration: underline;
        

    }
</style>
    <nav class="navbar navbar-expand-lg ">
        <a class="navbar-brand color-green hover-text font-weight-bold " href="index.php">Contact Management System</a>
        <ul class="navbar-nav mr-auto">
            <li class="nav-item">
                <a class="nav-link color-white hover-text" href="create_contact.php">Add Contact</a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <a class="nav-link color-white hover-text" href="logout.php">Logout</a>
            </li>
        </ul>
    </nav>
