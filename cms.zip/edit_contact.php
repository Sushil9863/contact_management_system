<!DOCTYPE html>
<html>
<head>
    <title>Edit Contact</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="styles.css">
</head>
<body>

<?php
include_once 'header.php';
include_once 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $contact_id = $_GET['id'];
    $stmt = $db->prepare('SELECT * FROM contacts WHERE id = ?');
    $stmt->execute([$contact_id]);
    $contact = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Handle form submission to update contact information in the database
    $contact_id = $_POST['contact_id'];
    $full_name = $_POST['full_name'];
    $email = $_POST['email'];
    $address = $_POST['address'];
    $nickname = $_POST['nickname'];
    $phone_number = $_POST['phone_number'];

    $stmt = $db->prepare('UPDATE contacts SET full_name = ?, email = ?, address = ?, nickname = ?, phone_number = ? WHERE id = ?');
    $stmt->execute([$full_name, $email, $address, $nickname, $phone_number, $contact_id]);
    header('Location: index.php');
    exit;
}
?>

<div class="container">
    <h1>Edit Contact</h1>
    <form action="edit_contact.php" method="POST">
        <input type="hidden" name="contact_id" value="<?php echo $contact['id']; ?>">
        <div class="form-group">
            <label for="full_name">Full Name:</label>
            <input type="text" class="form-control" name="full_name" value="<?php echo $contact['full_name']; ?>" required>
        </div>
        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" name="email" value="<?php echo $contact['email']; ?>" required>
        </div>
        <div class="form-group">
            <label for="address">Address:</label>
            <textarea class="form-control" name="address"><?php echo $contact['address']; ?></textarea>
        </div>
        <div class="form-group">
            <label for="nickname">Nickname:</label>
            <input type="text" class="form-control" name="nickname" value="<?php echo $contact['nickname']; ?>" required>
        </div>
        <div class="form-group">
            <label for="phone_number">Phone Number:</label>
            <input type="text" class="form-control" name="phone_number" value="<?php echo $contact['phone_number']; ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Save Changes</button>
        <a href="index.php" class="btn btn-secondary ml-2">Back to Dashboard</a>
    </form>
</div>

<?php
include_once 'footer.php';
?>

</body>
</html>
