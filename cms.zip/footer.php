<style> 
    /* body {
        display: flex;
        flex-direction: column;
        min-height: 100vh;
    }

    .container {
        flex: 1;
    }  */

    /* footer {
        position: absolute;
        bottom: 0;
        width: 100vw;
        text-align: center;
        background-color: #f5f5f5;
        padding: 10px 0;
    } */
</style>
<div class="footer">
    <footer class="text-light bg-dark">
        &copy; <?php echo date("Y"); ?> Prakash Paneru
    </footer>
</div>
</body>
