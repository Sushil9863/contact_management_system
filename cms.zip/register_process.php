<?php
require 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = $_POST['username'];
    $password = password_hash($_POST['password'], PASSWORD_BCRYPT);

    // Check if the username is already in use
    $stmt = $db->prepare('SELECT username FROM user_detail WHERE username = ?');
    $stmt->execute([$username]);
    $existingUsername = $stmt->fetch();

    if ($existingUsername) {
        // Username is already in use, handle accordingly (e.g., show an error message)
        echo "Username is already in use. Please choose a different username.";
    } else {
        // Insert the new user into the database
        $stmt = $db->prepare('INSERT INTO user_detail (username, password) VALUES (?, ?)');
        $stmt->execute([$username, $password]);

        header('Location: login.php');
        exit;
    }
}
?>